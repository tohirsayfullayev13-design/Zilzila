"""Zilzila ogohlantirish tizimi: backend (1-bosqich).

Vazifasi: USGS va EMSC'dan O'zbekiston atrofidagi zilzilalarni olish,
takrorlarni olib tashlash, SQLite'ga saqlash va yangi hodisa uchun notify() chaqirish.
Ishga tushirish: uvicorn main:app --reload
"""
import asyncio
import math
import sqlite3
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

import httpx
from fastapi import FastAPI

# ---- Sozlamalar -------------------------------------------------------
BBOX = {"minlat": 36.0, "maxlat": 46.0, "minlon": 55.0, "maxlon": 75.0}
MIN_MAG = 3.5
POLL_SECONDS = 45
LOOKBACK_HOURS = 3
DB_PATH = "zilzila.db"

CITIES = {
    "Toshkent": (41.30, 69.24), "Samarqand": (39.65, 66.96),
    "Buxoro": (39.77, 64.42), "Andijon": (40.78, 72.34),
    "Namangan": (41.00, 71.67), "Farg'ona": (40.38, 71.78),
    "Nukus": (42.46, 59.61), "Termiz": (37.22, 67.28),
    "Qarshi": (38.86, 65.79), "Urganch": (41.55, 60.63),
    "Navoiy": (40.10, 65.37), "Jizzax": (40.12, 67.84),
    "Guliston": (40.49, 68.78), "Dushanbe": (38.56, 68.77),
    "Bishkek": (42.87, 74.59), "Ashgabat": (37.95, 58.38),
    "Almaty": (43.24, 76.89),
}

# ---- Yordamchi funksiyalar ---------------------------------------------
def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def nearest_city(lat, lon):
    name, (clat, clon) = min(
        CITIES.items(), key=lambda c: haversine_km(lat, lon, *c[1])
    )
    return name, round(haversine_km(lat, lon, clat, clon))


def in_bbox(lat, lon):
    return (BBOX["minlat"] <= lat <= BBOX["maxlat"]
            and BBOX["minlon"] <= lon <= BBOX["maxlon"])


# ---- Ma'lumot manbalari ------------------------------------------------
async def fetch_usgs(client: httpx.AsyncClient):
    start = (datetime.now(timezone.utc) - timedelta(hours=LOOKBACK_HOURS)).strftime(
        "%Y-%m-%dT%H:%M:%S"
    )
    r = await client.get(
        "https://earthquake.usgs.gov/fdsnws/event/1/query",
        params={
            "format": "geojson", "starttime": start, "orderby": "time",
            "minmagnitude": MIN_MAG, "minlatitude": BBOX["minlat"],
            "maxlatitude": BBOX["maxlat"], "minlongitude": BBOX["minlon"],
            "maxlongitude": BBOX["maxlon"],
        },
    )
    r.raise_for_status()
    out = []
    for f in r.json().get("features", []):
        p, (lon, lat, depth) = f["properties"], f["geometry"]["coordinates"]
        if p.get("mag") is None:
            continue
        out.append({
            "id": f"usgs:{f['id']}", "source": "USGS", "mag": float(p["mag"]),
            "time": p["time"] / 1000, "lat": lat, "lon": lon,
            "depth": depth, "place": p.get("place") or "",
        })
    return out


async def fetch_emsc(client: httpx.AsyncClient):
    start = (datetime.now(timezone.utc) - timedelta(hours=LOOKBACK_HOURS)).strftime(
        "%Y-%m-%dT%H:%M:%S"
    )
    r = await client.get(
        "https://www.seismicportal.eu/fdsnws/event/1/query",
        params={
            "format": "json", "start": start, "orderby": "time",
            "minmag": MIN_MAG, "minlat": BBOX["minlat"], "maxlat": BBOX["maxlat"],
            "minlon": BBOX["minlon"], "maxlon": BBOX["maxlon"], "limit": 50,
        },
    )
    r.raise_for_status()
    out = []
    for f in r.json().get("features", []):
        p = f["properties"]
        t = datetime.fromisoformat(p["time"].replace("Z", "+00:00")).timestamp()
        out.append({
            "id": f"emsc:{p.get('unid', f.get('id'))}", "source": "EMSC",
            "mag": float(p["mag"]), "time": t, "lat": p["lat"], "lon": p["lon"],
            "depth": abs(p.get("depth") or 0), "place": p.get("flynn_region") or "",
        })
    return out


# ---- Saqlash va takrorlarni olib tashlash ------------------------------
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute(
        """CREATE TABLE IF NOT EXISTS quakes (
            id TEXT PRIMARY KEY, source TEXT, mag REAL, time REAL,
            lat REAL, lon REAL, depth REAL, place TEXT,
            city TEXT, city_km INTEGER)"""
    )
    return con


def is_duplicate(con, ev):
    """Boshqa manbadan kelgan xuddi shu zilzila: 2 daqiqa va 100 km ichida."""
    rows = con.execute(
        "SELECT lat, lon FROM quakes WHERE time BETWEEN ? AND ?",
        (ev["time"] - 120, ev["time"] + 120),
    ).fetchall()
    return any(haversine_km(ev["lat"], ev["lon"], r["lat"], r["lon"]) < 100 for r in rows)


def notify(ev):
    """2-bosqichda bu yerga Firebase (FCM) push yuborish qo'shiladi."""
    when = datetime.fromtimestamp(ev["time"], timezone.utc).strftime("%H:%M UTC")
    print(f"🚨 M{ev['mag']:.1f} | {ev['city']}dan {ev['city_km']} km | "
          f"chuqurlik {ev['depth']:.0f} km | {when} | {ev['source']}")


async def poll_once(client):
    events = []
    for fetch in (fetch_usgs, fetch_emsc):
        try:
            events += await fetch(client)
        except Exception as e:  # bitta manba ishlamasa, ikkinchisi davom etadi
            print(f"[xato] {fetch.__name__}: {e}")
    con = db()
    try:
        for ev in sorted(events, key=lambda e: e["time"]):
            if not in_bbox(ev["lat"], ev["lon"]):
                continue
            if con.execute("SELECT 1 FROM quakes WHERE id=?", (ev["id"],)).fetchone():
                continue
            if is_duplicate(con, ev):
                continue
            ev["city"], ev["city_km"] = nearest_city(ev["lat"], ev["lon"])
            con.execute(
                "INSERT INTO quakes VALUES (:id,:source,:mag,:time,:lat,:lon,"
                ":depth,:place,:city,:city_km)", ev,
            )
            con.commit()
            notify(ev)
    finally:
        con.close()


async def poll_loop():
    async with httpx.AsyncClient(timeout=15) as client:
        while True:
            await poll_once(client)
            await asyncio.sleep(POLL_SECONDS)


# ---- API ---------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(poll_loop())
    yield
    task.cancel()


app = FastAPI(title="Zilzila ogohlantirish", lifespan=lifespan)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/earthquakes")
def earthquakes(limit: int = 50, min_mag: float = MIN_MAG):
    con = db()
    rows = con.execute(
        "SELECT * FROM quakes WHERE mag >= ? ORDER BY time DESC LIMIT ?",
        (min_mag, min(limit, 200)),
    ).fetchall()
    con.close()
    return [dict(r) for r in rows]
