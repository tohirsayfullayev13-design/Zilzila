# Zilzila monitori

- `index.html` — dunyo zilzila xaritasi (USGS), sariq/qizil/to'q qizil darajalar, mamlakatlar bo'yicha ro'yxat, ogohlantirish. GitHub Pages orqali ochiladi.
- `backend/` — Python (FastAPI) server: USGS + EMSC, O'zbekiston atrofi.

Ishga tushirish (backend): `pip install -r backend/requirements.txt && uvicorn main:app --reload` (backend papkasida).
